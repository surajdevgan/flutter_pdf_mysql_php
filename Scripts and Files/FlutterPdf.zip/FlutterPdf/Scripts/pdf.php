<?php
$db = mysqli_connect("localhost","id14653062_kpgulati","apple%And1@#","id14653062_gulatimart"); 
if(!$db)
{
    echo "Error";
}

$result = $db->query("Select * from pdftable ORDER by id DESC");
$list = array();
if($result){
while($row =mysqli_fetch_assoc($result)){
$list[] = $row;
}
echo json_encode($list);
}